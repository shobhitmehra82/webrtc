var express = require('express');
var apn = require('apn');
require('ssl-root-cas').inject();
require('https').globalAgent.options.ca = require('ssl-root-cas/latest').create();
var router = express.Router();
var mongoUrl = 'mongodb://apiuser:c2cap1us3r#@52.168.31.221:27017?authMechanism=DEFAULT&authSource=c2c_uat';
const MongoClient = require('mongodb').MongoClient;
const assert = require('assert');
const dbName = 'c2c_uat';
router.get('/', function(req, res, next) {
  res.send('respond with a resource');
});
var fcm = require('fcm-notification');
var FCM = new fcm('c2capp-19230-firebase-adminsdk-6eazs-e36afdae0c.json');
var defaultRepEmail="naresh.rajdev20@gmail.com";
var token;

async function sendNotificationtoIOS(connectionId,token){
  console.log("sending push notification to IOS")
  var options = {
    token: {
      key: "AuthKey_23PMWUV3YV.p8",
      keyId: "23PMWUV3YV",
      teamId: "NQL478KXAA"
    },
    production: false
  };
  var apnProvider = new apn.Provider(options);
  //let deviceToken = "f18b5c233690ada1e30842559668e04b58513b3fd45d2b6e205e2e7a93ca5226";
 var note = new apn.Notification();
 var payload= {"callFrom": {"name": connectionId,"phone" : connectionId}};
  note.expiry = Math.floor(Date.now() / 1000) + 3600; // Expires 1 hour from now.
  note.badge = 3;
  note.sound = "ping.aiff";
  note.alert = "\uD83D\uDCE7 \u2709 You have a new call ";
  note.payload = payload;
  note.topic = "com.vgroup.context2call.voip";
  apnProvider.send(note, token).then( (result) => {
    console.log(result)
    // see documentation for an explanation of result
  });
}
function sendNotificationtoAndroid(connectionId,token){
  console.log("sending push notification to Android");
   message = {
    data: {    //This is only optional, you can send any data
      connectionId: connectionId,
      video:"false"
    },
    token : token
  };
  FCM.send(message, function(err, response){
    if(err){
      console.log('error found', err);
    }else{
      console.log('response here', response);
    }
  })
}

//Get User Token from db
async function getUserToken(emailId,getTokencallback){
MongoClient.connect(mongoUrl, function(err, client) {
    assert.equal(null, err);
    const db = client.db(dbName);
    const collection = db.collection('app_tokens');
    collection.find({
            'email': emailId
          }).toArray(function(err, docs) {
            token=docs[0].token;
            token=token.toString();
           return getTokencallback(token);
            
          });
    client.close();
})
}

//Send Notification to App - params[connectionId,emailId]
router.get('/sendNotification', function(req, res, next) {
  //sendIOSNotification()
  res.header("Access-Control-Allow-Origin", "*");
  var urlParams = new URLSearchParams(req.query);
  var connectionId =urlParams.get('connectionId');
  var emailId =urlParams.get('emailId');
  var appPlatform =urlParams.get('appPlatform');
  //emailId=emailId ? emailId : 'naresh.rajdev20@gmail.com';
  console.log(emailId);
  connectionId=connectionId.toString();
 getUserToken(emailId,function(token){
   console.log("getUserToken")
   if(appPlatform=="ANDROID"){
      sendNotificationtoAndroid(connectionId,token);
   }
   else if(appPlatform=="IOS"){
      sendNotificationtoIOS(connectionId,token);
   }
  });
  res.json({"message": "Notification sent Successfully","status":200});
});

router.get('/callReceived', function(req, res, next) {
  //var connectionId=
});

function saveUpdateUserToken(email,token){
  var isodate = new Date().toISOString()
    MongoClient.connect(mongoUrl, function(err, client) {
      assert.equal(null, err);
      console.log("Connected successfully to server");
      const db = client.db(dbName);
      const collection = db.collection('app_tokens');
      collection.updateOne({email:email},{$set:{token:token,updated_at:isodate}},{ upsert: true});
      client.close();
    });
}

router.post('/saveAppUserToken', function(req, res, next) {
  res.header("Access-Control-Allow-Origin", "*");
  var responseMessage;
  var responseCode;
  var email = req.body.email;
  var token = req.body.token;
  if(email==undefined){
    responseMessage="Invalid request.Missing Param:userId";
    responseCode=400; 
    if(token==undefined){
      responseMessage+=", token";
    }
  }
  else if(token==undefined){
    responseMessage="Invalid request.Missing Param:token ";
  }
  else{
    saveUpdateUserToken(email,token)
    responseMessage="Token saved successfully";
    responseCode=200 ;
  }
  res.json({"message": responseMessage,"status":responseCode});
});






// Connection URL

// Connection URL
//const url = 'mongodb://localhost:27017';
//var isodate = new Date().toISOString()
//console.log(isodate)
// Database Name


// Use connect method to connect to the server

module.exports = router;
